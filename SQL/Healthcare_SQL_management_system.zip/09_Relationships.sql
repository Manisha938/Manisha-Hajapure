-- HEALTHCARE DATABASE RELATIONSHIPS

-- Patient -> Medical_History = 1 : M
-- Patient -> Encounter = 1 : M
-- Doctor -> Encounter = 1 : M
-- Encounter -> Diagnostic_Test = 1 : M
-- Encounter -> Prescription = 1 : M
-- Encounter -> Procedure = 1 : M
-- Prescription -> Prescription_Medicine = 1 : M

-- FOREIGN KEY RELATIONSHIPS
-- Medical_History.Patient_ID -> Patient.Patient_ID
-- Encounter.Patient_ID -> Patient.Patient_ID
-- Encounter.Doctor_ID -> Doctor.Doctor_ID
-- Diagnostic_Test.Encounter_ID -> Encounter.Encounter_ID
-- Prescription.Encounter_ID -> Encounter.Encounter_ID
-- Procedure.Encounter_ID -> Encounter.Encounter_ID
-- Prescription_Medicine.Prescription_ID -> Prescription.Prescription_ID
