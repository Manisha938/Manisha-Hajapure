CREATE TABLE Diagnostic_Test(
    Test_ID INT PRIMARY KEY,
    Encounter_ID INT,
    Test_Type VARCHAR(100),
    Result VARCHAR(300),
    Test_Date DATE,
    FOREIGN KEY(Encounter_ID)
    REFERENCES Encounter(Encounter_ID)
);

DESC Diagnostic_Test;

INSERT INTO Diagnostic_Test VALUES
(1,1,'Blood Pressure Test','BP 150/95 - High','2026-06-01'),
(2,2,'MRI Brain','No abnormality detected','2026-06-02'),
(3,3,'X-Ray Spine','Mild lumbar changes','2026-06-03'),
(4,4,'Skin Examination','Moderate acne','2026-06-04'),
(5,5,'HbA1c Test','HbA1c 7.4 percent','2026-06-05'),
(6,6,'CBC Test','Hemoglobin 8.9 g/dL','2026-06-06'),
(7,7,'Spirometry','Mild obstruction','2026-06-07'),
(8,8,'Ear Examination','Middle ear infection','2026-06-08'),
(9,9,'Ultrasound Abdomen','No major abnormality','2026-06-09'),
(10,10,'Allergy Test','Pollen sensitivity','2026-06-10');

SELECT * FROM Diagnostic_Test;
