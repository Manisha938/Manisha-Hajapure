CREATE TABLE Encounter(
    Encounter_ID INT PRIMARY KEY,
    Patient_ID INT,
    Doctor_ID INT,
    Appointment_Date DATE,
    Admission_Date DATE,
    Discharge_Date DATE,
    FOREIGN KEY(Patient_ID)
    REFERENCES Patient(Patient_ID),
    FOREIGN KEY(Doctor_ID)
    REFERENCES Doctor(Doctor_ID)
);

DESC Encounter;

INSERT INTO Encounter VALUES
(1,101,1,'2026-06-01','2026-06-01','2026-06-03'),
(2,102,2,'2026-06-02','2026-06-02','2026-06-04'),
(3,103,3,'2026-06-03','2026-06-03','2026-06-05'),
(4,104,4,'2026-06-04','2026-06-04','2026-06-06'),
(5,105,5,'2026-06-05','2026-06-05','2026-06-07'),
(6,106,6,'2026-06-06','2026-06-06','2026-06-08'),
(7,107,7,'2026-06-07','2026-06-07','2026-06-09'),
(8,108,8,'2026-06-08','2026-06-08','2026-06-10'),
(9,109,9,'2026-06-09','2026-06-09','2026-06-11'),
(10,110,10,'2026-06-10','2026-06-10','2026-06-12');

SELECT * FROM Encounter;
