CREATE TABLE Prescription_Medicine(
    Medicine_ID INT PRIMARY KEY,
    Prescription_ID INT,
    Medicine_Name VARCHAR(100),
    Dosage VARCHAR(100),
    Frequency VARCHAR(100),
    Duration VARCHAR(100),
    FOREIGN KEY(Prescription_ID)
    REFERENCES Prescription(Prescription_ID)
);

DESC Prescription_Medicine;

INSERT INTO Prescription_Medicine VALUES
(1,1,'Amlodipine','5 mg','Once daily','30 days'),
(2,2,'Sumatriptan','50 mg','As needed','10 days'),
(3,3,'Ibuprofen','400 mg','Twice daily','7 days'),
(4,4,'Adapalene Gel','0.1%','Once nightly','30 days'),
(5,5,'Metformin','500 mg','Twice daily','60 days'),
(6,6,'Ferrous Sulfate','325 mg','Once daily','90 days'),
(7,7,'Salbutamol Inhaler','100 mcg','As needed','30 days'),
(8,8,'Amoxicillin','500 mg','Three times daily','7 days'),
(9,9,'Pantoprazole','40 mg','Once daily','14 days'),
(10,10,'Cetirizine','10 mg','Once daily','10 days');

SELECT * FROM Prescription_Medicine;
