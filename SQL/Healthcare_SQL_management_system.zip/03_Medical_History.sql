CREATE TABLE Medical_History(
    History_ID INT PRIMARY KEY,
    Patient_ID INT,
    Diagnosis VARCHAR(200),
    Allergies VARCHAR(200),
    Medications VARCHAR(200),
    Previous_Treatment VARCHAR(300),
    FOREIGN KEY(Patient_ID)
    REFERENCES Patient(Patient_ID)
);

DESC Medical_History;

INSERT INTO Medical_History VALUES
(1,101,'Hypertension','No Allergy','Amlodipine','Blood pressure monitoring'),
(2,102,'Migraine','Dust Allergy','Sumatriptan','Migraine treatment'),
(3,103,'Back Pain','No Allergy','Ibuprofen','Physiotherapy'),
(4,104,'Acne','Pollen Allergy','Adapalene','Skin treatment'),
(5,105,'Type 2 Diabetes','No Allergy','Metformin','Diet control'),
(6,106,'Iron Deficiency','No Allergy','Iron Supplement','Iron therapy'),
(7,107,'Asthma','Dust Allergy','Salbutamol','Inhaler treatment'),
(8,108,'Ear Infection','No Allergy','Amoxicillin','Antibiotic treatment'),
(9,109,'Gastritis','Spice Sensitivity','Pantoprazole','Diet modification'),
(10,110,'Seasonal Allergy','Pollen Allergy','Cetirizine','Antihistamine treatment');

SELECT * FROM Medical_History;
