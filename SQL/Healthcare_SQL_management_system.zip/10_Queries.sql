-- BASIC AND JOIN QUERIES

SELECT * FROM Patient;

SELECT * FROM Doctor;

SELECT * FROM Medical_History;

SELECT * FROM Encounter;

SELECT * FROM Diagnostic_Test;

SELECT * FROM Prescription;

SELECT * FROM Procedure;

SELECT * FROM Prescription_Medicine;

-- Patient with Doctor
SELECT
    p.Patient_Name,
    d.Doctor_Name,
    d.Specialization,
    e.Appointment_Date
FROM Patient p
JOIN Encounter e ON p.Patient_ID = e.Patient_ID
JOIN Doctor d ON e.Doctor_ID = d.Doctor_ID;

-- Patient medical history
SELECT
    p.Patient_Name,
    m.Diagnosis,
    m.Allergies,
    m.Medications
FROM Patient p
JOIN Medical_History m
ON p.Patient_ID = m.Patient_ID;

-- Diagnostic test report
SELECT
    p.Patient_Name,
    d.Doctor_Name,
    dt.Test_Type,
    dt.Result,
    dt.Test_Date
FROM Patient p
JOIN Encounter e ON p.Patient_ID = e.Patient_ID
JOIN Doctor d ON e.Doctor_ID = d.Doctor_ID
JOIN Diagnostic_Test dt ON e.Encounter_ID = dt.Encounter_ID;

-- Prescription medicines
SELECT
    p.Patient_Name,
    pm.Medicine_Name,
    pm.Dosage,
    pm.Frequency,
    pm.Duration
FROM Patient p
JOIN Encounter e ON p.Patient_ID = e.Patient_ID
JOIN Prescription pr ON e.Encounter_ID = pr.Encounter_ID
JOIN Prescription_Medicine pm
ON pr.Prescription_ID = pm.Prescription_ID;

-- Number of encounters handled by each doctor
SELECT
    d.Doctor_Name,
    COUNT(e.Encounter_ID) AS Total_Encounters
FROM Doctor d
LEFT JOIN Encounter e
ON d.Doctor_ID = e.Doctor_ID
GROUP BY d.Doctor_ID, d.Doctor_Name;
