CREATE TABLE Procedure(
    Procedure_ID INT PRIMARY KEY,
    Encounter_ID INT,
    Procedure_Name VARCHAR(150),
    Procedure_Date DATE,
    Description VARCHAR(300),
    FOREIGN KEY(Encounter_ID)
    REFERENCES Encounter(Encounter_ID)
);

DESC Procedure;

INSERT INTO Procedure VALUES
(1,1,'Blood Pressure Monitoring','2026-06-01','Repeated blood pressure measurement'),
(2,2,'Neurological Examination','2026-06-02','Basic neurological assessment'),
(3,3,'Physiotherapy Assessment','2026-06-03','Lumbar mobility assessment'),
(4,4,'Skin Assessment','2026-06-04','Detailed skin assessment'),
(5,5,'Diabetes Counseling','2026-06-05','Diet and lifestyle counseling'),
(6,6,'Iron Therapy Monitoring','2026-06-06','Monitoring iron treatment'),
(7,7,'Pulmonary Examination','2026-06-07','Respiratory system assessment'),
(8,8,'Ear Cleaning','2026-06-08','Clinical ear cleaning'),
(9,9,'Abdominal Examination','2026-06-09','Physical abdominal examination'),
(10,10,'Allergy Assessment','2026-06-10','Seasonal allergy assessment');

SELECT * FROM Procedure;
