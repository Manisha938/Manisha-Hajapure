CREATE TABLE Prescription(
    Prescription_ID INT PRIMARY KEY,
    Encounter_ID INT,
    Prescription_Date DATE,
    Instructions VARCHAR(300),
    FOREIGN KEY(Encounter_ID)
    REFERENCES Encounter(Encounter_ID)
);

DESC Prescription;

INSERT INTO Prescription VALUES
(1,1,'2026-06-01','Take medicine once daily after breakfast'),
(2,2,'2026-06-02','Take medicine as prescribed for migraine'),
(3,3,'2026-06-03','Take after food and continue physiotherapy'),
(4,4,'2026-06-04','Apply cream at night'),
(5,5,'2026-06-05','Take medicine after meals'),
(6,6,'2026-06-06','Take supplement after meals'),
(7,7,'2026-06-07','Use inhaler as directed'),
(8,8,'2026-06-08','Complete antibiotic course'),
(9,9,'2026-06-09','Take medicine before breakfast'),
(10,10,'2026-06-10','Take antihistamine once daily');

SELECT * FROM Prescription;
