CREATE TABLE Doctor(
    Doctor_ID INT PRIMARY KEY,
    Doctor_Name VARCHAR(100),
    Specialization VARCHAR(100),
    Phone VARCHAR(15),
    Email VARCHAR(100)
);

DESC Doctor;

INSERT INTO Doctor VALUES
(1,'Dr. Amit Desai','Cardiology','9000000001','amit@hospital.com'),
(2,'Dr. Priya Shah','Dermatology','9000000002','priya@hospital.com'),
(3,'Dr. Raj Mehta','Orthopedics','9000000003','raj@hospital.com'),
(4,'Dr. Neha Joshi','Gynecology','9000000004','neha@hospital.com'),
(5,'Dr. Suresh Patil','Neurology','9000000005','suresh@hospital.com'),
(6,'Dr. Kavita More','Pediatrics','9000000006','kavita@hospital.com'),
(7,'Dr. Rohit Kulkarni','General Medicine','9000000007','rohit@hospital.com'),
(8,'Dr. Snehal Pawar','ENT','9000000008','snehal@hospital.com'),
(9,'Dr. Nitin Jadhav','Gastroenterology','9000000009','nitin@hospital.com'),
(10,'Dr. Asha Shinde','Pulmonology','9000000010','asha@hospital.com');

SELECT * FROM Doctor;
