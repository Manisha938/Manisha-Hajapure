CREATE TABLE Patient(
    Patient_ID INT PRIMARY KEY,
    Patient_Name VARCHAR(100),
    DOB DATE,
    Gender VARCHAR(10),
    Phone VARCHAR(15),
    Email VARCHAR(100),
    Address VARCHAR(200),
    Insurance_Info VARCHAR(200)
);

DESC Patient;

INSERT INTO Patient VALUES
(101,'Aarav Sharma','1995-04-12','Male','9876543210','aarav@gmail.com','Pune Maharashtra','Star Health'),
(102,'Ananya Patil','1998-08-21','Female','9876543211','ananya@gmail.com','Nanded Maharashtra','HDFC Ergo'),
(103,'Rohan Deshmukh','1992-01-15','Male','9876543212','rohan@gmail.com','Mumbai Maharashtra','ICICI Lombard'),
(104,'Sneha Kulkarni','2000-11-03','Female','9876543213','sneha@gmail.com','Nagpur Maharashtra','Star Health'),
(105,'Vivek Joshi','1988-06-27','Male','9876543214','vivek@gmail.com','Nashik Maharashtra','Aditya Birla'),
(106,'Pooja Jadhav','1996-09-18','Female','9876543215','pooja@gmail.com','Aurangabad Maharashtra','HDFC Ergo'),
(107,'Kunal More','1985-12-10','Male','9876543216','kunal@gmail.com','Kolhapur Maharashtra','ICICI Lombard'),
(108,'Meera Pawar','1999-03-25','Female','9876543217','meera@gmail.com','Solapur Maharashtra','Star Health'),
(109,'Rahul Shinde','1990-07-14','Male','9876543218','rahul@gmail.com','Satara Maharashtra','Aditya Birla'),
(110,'Neha Chavan','2001-05-30','Female','9876543219','neha@gmail.com','Latur Maharashtra','HDFC Ergo');

SELECT * FROM Patient;
